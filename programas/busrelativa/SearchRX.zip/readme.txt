        ______         _   _____    _____ ______     
       /   __/  ___   | | /     \  /  ___/   __/     
       \___  \ \__ \__| |/   |   \/  ___/\___  \     
      /       \/ . / .  |    |    \     /       \     
      \_______/\___\____|____|____/____/\_______/    
                          ______                     
                      __ /      \                    
         |        ___|  \\__  __/_ __       |        
        -+-      / __|   \ /  \/  |  \     -+-       
         |      /    |    \    \  |  /      |        
                \____|____/____/\   /                
                  -Fraka-       /__/                 
                                                   

             http://www.sadnes.emuita.it
           
                       Presents:

======================================================
                   SearchR X v1.0
                      by Chop_
                     25-04-2002
======================================================

------------------------------------------------------
1 - WHAT'S THIS ?            
------------------------------------------------------

SearchR X is a program that let you execute a relative
search in files of any size.
Unlike most search programs, in fact, this one doesn't
load the file in memory before executing the research,
thus  it is  possible to  search even  in isos  or bin 
files (usually VERY large).
The main disadvantage  is maybe speed,  but minimizing 
the search routine i managed to scan 1Mb in about half
a second  (Not counting  the time used  to display the 
results).
The program run under  windows, so the incompatibility 
issues  with  the plain  old dejap's  SerachR, can  be 
forgotten...
SearchR X has been tested with win98 and winXP, but it 
should work  well also  under other window's  versions 
(never trust microsoft... :))


------------------------------------------------------
2 - WHAT'S NEW            
------------------------------------------------------

v1.0
-Fixed  a  nasty  bug that  occurs  while searching in 
 large files;
-Added a sort of Hexadecimal viewer (double-click on a
 result to activate);            //Still in Test stage
-Added an option menu;
-Minor bugs fixed.


------------------------------------------------------
3 - KNOWN BUGS            
------------------------------------------------------

-Problems with the hexadecimal viewer (various :P).


------------------------------------------------------
4 - ABOUT MULTILANGUAGE FEATURE            
------------------------------------------------------

From version 0.9  SearchR  X comes  with an extra-cool
multilanguage feature.
Essentially you can translate the program in different
languages easily and rapidly.
You can find all the text displyed by the interface in
the  file named  "languages.dat",  that  can be freely
opened and edited with notepad.

Now you can select  your  favourite  language from the
option menu!
Simply  append your  translation to  languages.dat and
select it from the menu.
If you  have  made  a  translation  send  your file to
chop_@libero.it and i will  include it in the official
release! (of course you will have your credits).


------------------------------------------------------
5 - FOR THE FUTURE...            
------------------------------------------------------

I don't really  know what  i'm going to insert  in the 
program, maybe i try to embetter the Hex Viewer... who
knows?

Just wait for a new release ;)
Naturally, if you have suggestions about new features,
just let me know.


------------------------------------------------------
6 - ABOUT THE AUTHOR            
------------------------------------------------------

Hi! I hope that you liked my program!
I'm working constantly on it.
I've got  lots of  interesting  ideas i  would like to 
implement as soon  as possible,  to make SearchR X the
best relative searcher ever! eheheh... :)
If you  have suggestion,  hints, or if  you  find some
bugs, let me know!
I'm avaiable via e-mail at chop_@libero.it
Come on www.emuita.it!

And visit www.sadnes.emuita.it home of 

                      SadNES cITy 
        the first italian ROM translation group!

Stay tune!

