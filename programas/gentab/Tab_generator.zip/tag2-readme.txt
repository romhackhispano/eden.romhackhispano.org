 *-=*=-=-=*=-=-=*=-=-=*=-=-=*=-=-=*=-=-=*=-=-=*=-=-=*=-=-=*=-*
 +                                                           +
 *                    Table Auto-Generator                   *
 +                                                           +
 *                           v2.b                            *
 +                                                           +
 *                        by InVerse                         *
 +                                                           +
 *                         02/28/03                          *
 +                                                           +
 *-=*=-=-=*=-=-=*=-=-=*=-=-=*=-=-=*=-=-=*=-=-=*=-=-=*=-=-=*=-*
 
 This serves as basic documentation for version 2.Beta of
 Table Auto-Generator.
 
 TAG 2.Beta is a complete re-write of Table Auto-Generator. At
 the present, the Beta version should be identical to TAG 1.0
 with the exception of all known bugs from 1.0 being fixed. I
 also changed the Other section around a bit and redid the
 method in which the Japanese characters are displayed.
 
 TAG 2.Beta now requires the installation of a custom font
 which is included with the archive. Use of the font resulted
 in TAG 2.Beta being less than half the size of TAG 1.0 (even
 after you factor in the file size of the TTF as well.)
 
 Known bugs that have been fixed from version 1.0:
 
 * numerals now output correctly to the table
 * EUC now works, for some reason it was crashing
 * ? has been added to the punctuation section *blush*
 
 
 As the name suggests, this program is still in beta testing.
 I intend to add a few new features before releasing an official
 2.0 version. I'm releasing the beta to the public to see if
 there are any bugs I'm not aware of, as well as to see if
 there are any suggestions for features to implement into the
 final version.
 
 Tag 2.Beta is written in Microsoft Visual Basic 6.0 and
 requires the VB6 runtime files. These can be obtained from
 http://support.microsoft.com/default.aspx?scid=kb;en-us;q192461
 and I will not send them to you. If you get an error message
 saying any other file is required, just type that filename into
 Google and you'll find a download source.
 
 If you encounter any bugs not related to missing a required file
 or if you have any suggestions for how to improve TAG, please
 e-mail me at inverse@pigtails.net.