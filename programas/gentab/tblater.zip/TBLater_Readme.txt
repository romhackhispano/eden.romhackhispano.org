+----------------------------------------------------------+
                                                            
 TBLaterTB  aterTBL    rTB   #####    #       ####   # ###  
 LaterTBLa  erTBLater  BLa        #   #      #    #  ##   # 
    TBL     TBL   rTB  ate    #####  #####   ######  #      
    rTB     rTBLater   Lat   #    #   #      #       #      
    erT     TBLaterT   ate   #    #   #   #  #    #  #      
    rTB     ter   Lat  TBL    ####     ###    ####   #      
    ter     TBL   Bla  rTB                                  
    ate     rTBLater   aterTBLat    :TBLater Version 1.0    
    erT     LaterTB    rTBLaterT    :Created By: Ken Price  
                                                            
+----------------------------------------------------------+
                                                            
                      ::Introduction::                      
Wow, you're really reading this? I'm amazed. Well, since you
are reading this, you might as well read whole intro while
you're at it. Oh, shut up! It's not that long so there's no
need to complain. I programmed TBLater in Visual Basic 6,
which isn't so bad of a programming language like some may
think. You might notice that I used common dialogs without
the control. That's because I'm using the API for it, which
I'm practicing by making programs like this. I'm working on
more programs that _might_ benefit ROM hackers by providing
them with _somewhat_ useful tools. If this isn't useful to
you, you're more than welcome to send me suggestions on the
program. My e-mail address is: vbvanguard@yahoo.com.
                                                            
        =------------------------------------------=        
                                                            
                      ::Instructions::                      
Thanks for using TBLater! I'm assuming you are familiar with
table files, so if you, by any chance, not familiar with
table files, please learn how to use it first. To start
making table files, open up the program. You should see a
grid with hex numbers 0-F on the left and on the top. Let's
say you wanted 0A to be A. In a table file you will put it
as "0A=A". In this program, you look for 0 on the left side,
and A on the top, and where it intersects is where you type 
"A". Don't get it? Well, that's too bad. You can figure it
out on your own, unless you're an idiot (or never learned
how to use table files).
                                                            
        =------------------------------------------=        
                                                            
                       ::Contact Me::                       
If you have any suggestions, requests, complaints, flames,
bombs, money, comments, viruses, money, or anything you want
to send to me, contact me using the information below:

E-mail: vbvanguard@yahoo.com
AIM: vbvanguard
                                                            
+----------------------------------------------------------+
               (- Saturday, March 15, 2003 -)               
      #   #   #   #   #  ###   #   #   #   ####  ####       
  #   #   #  # #  ##  # #      #   #  # #  #   # #   #   #  
 ###  #   # #   # # # # #  ### #   # #   # ####  #   #  ### 
  #    # #  ##### #  ## #   #  #   # ##### #   # #   #   #  
        #   #   # #   #  ###    ###  #   # #   # ####       
+----------------------------------------------------------+