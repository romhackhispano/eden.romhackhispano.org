Introduction to Infontile 1.0 


What is Infontile?

Infontile is a bitplane-based graphical-tile file editor and translation tool for 32-bit Windows (Windows 95, Windows 98, Windows NT, Windows 2000).

Features:

- Long filename support
- Can be used as "Send to"-Target
- Editable file size limited only by available system memory
- Small program footprint (around 150K)
- 100% FREE!

Editing Features:

- Extract/Insert 8x8 tiles using 2,4, 8, or 16 colors and 8x12 tiles using 2 or 4 colors
- Draw, edit, flip, mirror, & shift tiles in built-in editor
- Cut, copy, & paste graphical tiles between instances of Infontile
- Arrange tiles on a temporary canvas to see the "bigger picture" or organize them for import into another file
- Instant jumps to a particular offset
- Load files from a specified offset to account for header information
- Export/Import tiles to/from bitmap format

� Brian Bennewitz 2000 