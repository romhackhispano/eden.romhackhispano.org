SNES Sprite Editor Beta Version 1.0

This editor seems to work fine for editing tiles encoded in 1, 2 and 4 bitplanes.  
At this point, the settings for eight bitplanes are inoperative as I'm not too certain how
they work.  

It's slow.  Be warned.

If anyone knows how to encode bitmaps on the fly from data without using any of the windows 
GDI objects (aside of course from CBitmap) please drop me some E-mail at 
slindsay@iastate.edu.  

If you run into a bug or have some brilliant epiphany as to how this editor could be 
improved, yet again, drop me some mail. 

Also, you will notice that the colors are completely whacked.  
The colors for indexes above something like 7 are just random RGB references.  Quatch and I 
are eventually going to write an emulator front-end that will figure out the actual values
for the colors so everything will work right.  Until then, suffer.

I wrote this little gem with Visual C++ 5.0.  If you want the source code you're welcome to
it, just make sure that the right people get credit where credit is due.  

Well, there you have it.  Enjoy.